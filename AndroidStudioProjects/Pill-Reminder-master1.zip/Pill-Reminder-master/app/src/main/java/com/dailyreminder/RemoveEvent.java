package com.dailyreminder;

/**
 * Created by João on 20/08/2016.
 */
public class RemoveEvent {

    public int position, listPosition;

    public RemoveEvent(int position, int listPosition) {
        this.position = position;
        this.listPosition = listPosition;
    }
}
